# V218 official fixed-roster results

PASS_BOUNDED_CONTROL

| Arm | Final crossed-rendering terminal success |
|---|---:|
| ALIGNED | 99.41% |
| SHUFFLED | 42.58% |
| NO-WRITE | 25.78% |

Both complementary goals succeeded in 98.83% of paired tests.

16 worlds completed acquisition, first-action mapping reversal and interference.

The learned goal-to-action-sequence recency table and observed-transition graph are evaluator-side references with parsed fields. This task supports bounded action learning, not E3 structure reuse. See SUMMARY.json for all paired intervals.

## Operations and scope

Two audit/reference interface errors interrupted execution. The first world was replayed after a tuple/list comparison correction, with the failed attempt preserved. A later evaluator reference emitted an invalid motor after raw-byte collisions; the reference now scores that output as failure. Seven committed worlds and pending world 7 were reused without retraining. Learner, dynamics and dose were unchanged.

Total charged training including engineering and the failed first-world replay is 24,320 episodes, within 26,000. The CPU number in SUMMARY is final-continuation CPU only and is not a complete cumulative CPU measurement.

Final learned-reference successes, on their parsed-field 256-case panel: {'learned_graph': 1.0, 'goal_recency': 0.984375, 'fixed_motor': 0.25, 'motor_frequency': 0.25, 'oracle': 1.0}. They delimit the result to bounded E1/E2 control. Student-t intervals are reported untruncated and can extend beyond [0,1].
