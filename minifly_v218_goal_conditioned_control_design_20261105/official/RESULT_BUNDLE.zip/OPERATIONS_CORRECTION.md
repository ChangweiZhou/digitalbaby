# V218 audit interface correction

The initial official attempt trained world 0, then its new auditor rejected the in-memory wrapper tuple because it compared against JSON lists. The learner, environment and seed roster were unchanged. No world was committed. The initial attempt directory is preserved.

The auditor now normalizes wrapper values to tuples and writes the pending world result before audit. The corrected attempt replays world 0 because its initial in-memory result was not persisted. Charge that first 1,280 episodes, 2,560 actions and 5,120 slot updates as failed-attempt carry. Including both engineering worlds and that attempt, total training remains 24,320 episodes, below the 26,000 cap. Every retained committed result is from one complete run of the fixed learning schedule in the corrected attempt.

The evaluator-only recency reference later encountered overlapping raw state bytes from the interference ecology and emitted a motor outside the main ecology's motor alphabet. A reference invalid action now scores failure. Seven committed worlds and the pending world 7 are reused from disk without retraining; remaining worlds run once. The original source lock and failure status are preserved alongside the continuation source lock.
