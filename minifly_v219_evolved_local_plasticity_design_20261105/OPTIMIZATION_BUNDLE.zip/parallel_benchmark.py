"""Isolated process scheduling benchmark; no new scientific worlds."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
import subprocess
import sys
import time


CODE="""import json,search
r=search.run()
print(json.dumps({k:r[k] for k in ('log','nominees','selected','peak_rss_bytes')}))
"""


def job(_):
    result=subprocess.run([sys.executable,"-B","-c",CODE],capture_output=True,
                          text=True,check=True,env=dict(os.environ,OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1"))
    return json.loads(result.stdout)


def schedule(workers):
    start=time.monotonic()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        rows=list(pool.map(job,range(2)))
    return time.monotonic()-start,rows


serial,a=schedule(1)
parallel,b=schedule(2)
for left,right in zip(a,b):
    assert all(left[k]==right[k] for k in ("log","nominees","selected"))
print(json.dumps(dict(jobs=2,serial_wall=serial,parallel_wall=parallel,
                      speedup=serial/parallel,
                      summed_child_peak_rss_bytes=sum(r["peak_rss_bytes"] for r in b),
                      exact_search_outputs=True,science="NOT_RUN"),indent=2))
