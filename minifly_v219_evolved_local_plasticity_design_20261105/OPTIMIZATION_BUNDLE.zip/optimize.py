"""Compare source sensory evaluation with cached/prepared evaluation."""
import json
import resource
import time

import numpy as np

from learner import Learner,prior,sensor
from prepared import Prepared
from search import make_data,key

sense=sensor()
records=make_data("speed_parity",8192)
symbols=[int(token) for raw,_ in records for token in raw]
birth=key("speed_parity|birth")
plain=Learner(prior(),birth,sense)
fast=plain.fork()
begin=time.process_time()
prepared=Prepared(symbols,plain)
build=time.process_time()-begin
cpu=[0.,0.]
for i,token in enumerate(symbols):
    code=prepared.code(i)
    assert np.array_equal(sense.encode(plain.fe*.95),code)
    values=[None,None]
    for which in (0,1) if i%2 else (1,0):
        begin=time.process_time()
        values[which]=(plain.step(token) if which==0 else fast.step(token,sensory_code=code))
        cpu[which]+=time.process_time()-begin
    assert values[0][1]==values[1][1]
    for name in ("h","fe","O","bias"):
        assert np.array_equal(getattr(plain,name),getattr(fast,name))
    assert all(np.array_equal(a,b) for a,b in zip(plain.fast+plain.trace,fast.fast+fast.trace))
assert plain.generate()==fast.generate()
print(json.dumps(dict(sites=len(symbols),bitwise_parity=True,baseline_cpu=cpu[0],
                      prepared_cpu=cpu[1],build_cpu=build,
                      speedup_including_one_build=cpu[0]/(cpu[1]+build),
                      packed_bytes=prepared.packed.nbytes,
                      projected_cpu_with_reserve=66846720*(cpu[1]+build)/len(symbols)*1.25,
                      peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),indent=2))
