"""Full reduced-search parity against the unprepared sensor path."""
from copy import deepcopy
import json
from pathlib import Path
import time

import numpy as np

import search
from learner import Learner,prior,sensor
from prepared import Prepared


def reference(z,label,sense,limit):
    net=Learner(z,search.key(label+"|birth"),sense)
    records=search.make_data(label,limit)
    values=[]
    for j,(raw,start) in enumerate(records):
        for i,symbol in enumerate(raw):
            _,loss,_=net.step(int(symbol))
            if j>=3*len(records)//4 and i>=start and len(values)<128:
                values.append(loss)
    return float(np.mean(values)),net,records


fast=search.fitness
search.fitness=reference
a=search.run()
search.fitness=fast
search.prepared_life.cache_clear()
b=search.run()
for field in ("log","nominees","selected"):
    assert a[field]==b[field],field
# The cache's codes preceding an altered future symbol must be identical.
sense=sensor()
net=Learner(prior(),123,sense)
original=[*range(128),256]
modified=original.copy()
modified[91]=256
x=Prepared(original,net)
y=Prepared(modified,net)
assert np.array_equal(x.packed[:92],y.packed[:92])
print(json.dumps(dict(reduced_search_exact=True,genomes_fitness_and_selection_equal=True,
                      future_symbol_perturbation_passed=True,
                      reference_cpu=a["cpu_seconds"],prepared_cpu=b["cpu_seconds"],
                      search_speedup=a["cpu_seconds"]/b["cpu_seconds"],
                      cache=search.prepared_life.cache_info()._asdict(),
                      science="NOT_RUN"),indent=2))
