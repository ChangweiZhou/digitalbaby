# V219 sensory preparation and shared lifetime execution

Date 2026-11-05. Optimized engineering entry point implemented. Full scientific search NOT_RUN. The original three-cycle receipts and technical bundle remain historical evidence.

Profiling the reduced search attributed approximately 72% of measured cumulative time to native sensory encoding. That encoding depends on birth-specific receptor state and the already delivered symbols. It is independent of the candidate's fast-weight rule. Candidates evaluated on the same stream and birth can therefore share causal sensory activities.

## Implemented path

prepared.py computes the exact continuous sensory-state trajectory and projects it in bounded 128-site batches. Positive top-k selection preserves ascending KC-index tie resolution. Activities are stored as packed bits, with 648 bytes per symbol, then decoded for the recurrent update. The search cache holds at most four immutable prepared lives. A 16-KiB life requires 10,616,832 bytes of packed activities. The full network, synaptic traces and learning still advance separately, in original temporal order for every genome.

Preparation is used only at birth on the fixed observed stream with its correct birth-specific EOS receptor. Its cache key is the deterministic engineering lifetime label and length, which fix the stream and birth. This is not a prefix-only cache on an arbitrary recurrent or sensory state. Future production sources and stream manifests must also be locked before sharing. Autonomous self-generation retains the ordinary online sensor path.

## Executed checks and timings

- 8,192-symbol baseline/prepared comparison matched every code, recurrent state, fast weight, trace, output weight/bias and loss bit for bit. Final autonomous outputs also matched.
- Perturbing a later revealed symbol preserved all prepared codes through the prediction boundary before its arrival.
- The complete reduced two-generation ES/random-search run produced identical offspring losses, nominees and selected genomes with and without preparation.
- Reference search CPU was 7.982643 seconds; prepared search CPU was 2.317967 seconds, a measured 3.44× speedup. This includes creating prepared lives.
- On the longer parity benchmark, original per-symbol CPU totaled 2.723322 seconds. Prepared updates took 0.685511 seconds, with 0.679556 seconds to build the sensory stream. Even charging one preparation to one candidate gives approximately 2× improvement. Reuse across candidates supplies the larger search speedup.

The benchmark's longer-loop estimate is approximately 13,924 CPU seconds (3.87 hours) for the designed 66,846,720 lifetime applications with 25% reserve, conservatively charging one preparation per candidate. Decoding packed codes adds a small cost not isolated in that per-update timer. Final probes, references, qualification and supervision still require a complete census. The new estimate supplies headroom under the proposed eight-hour limit, without establishing full experiment admission.

See PARALLEL_BENCHMARK.json for isolated two-process wall-time and child-memory measurements. Concurrent jobs preserve their own update order. Peak child memory excludes controller overhead. No GPU path was executed.

## Reproduction

Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 with the same supported NumPy/SciPy environment used for qualification. Run optimize.py, search_parity.py and parallel_benchmark.py, retaining their JSON outputs. search.py now uses immutable sensory preparation automatically; Learner.step without a supplied prepared code retains the baseline path.

The profiling invocation initially wrote the revised search output to the historical second-cycle filename. CYCLE2_TEST.json was restored byte-for-byte from the original TECHNICAL_BUNDLE.zip. Optimization outputs have separate filenames.
