"""V219 sparse recurrent byte learner with fixed error broadcast."""
from copy import copy
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
_spec=spec_from_file_location("v219_sensor",ROOT/"minifly_v181_mini_local_plasticity_dev_20261102/sensor.py")
_mod=module_from_spec(_spec)
_spec.loader.exec_module(_mod)


def sensor():
    return _mod.Sensor()


def prior():
    values=[np.arctanh(.5),0,0,0,np.log(3),np.log(.9/(.999-.9)),
            np.log(.001/.009),np.log(1/4),0,np.log(.49/.5)]
    return np.array(values*2)


def transform(z):
    v=np.asarray(z).reshape(2,10)
    sigmoid=lambda x: 1/(1+np.exp(-np.clip(x,-60,60)))
    rows=[]
    for q in v:
        rows.append((*np.tanh(q[:4]),10**(-6+4*sigmoid(q[4])),.999*sigmoid(q[5]),
                     .01*sigmoid(q[6]),5*sigmoid(q[7]),np.tanh(q[8]),.01+.99*sigmoid(q[9])))
    return rows


class Learner:
    def __init__(self,z,birth,sense):
        self.sensor=sense
        r=np.random.default_rng(np.random.SeedSequence([birth,1]))
        self.inputs=np.array([r.choice(5177,16,replace=False) for _ in range(128)])
        self.rec=np.array([r.choice(128,8,replace=False) for _ in range(128)])
        r=np.random.default_rng(np.random.SeedSequence([birth,2]))
        self.slow=[r.normal(size=(128,16)),r.normal(size=(128,8))]
        self.slow=[(w/abs(w).sum(1,keepdims=True)*scale).astype(np.float32)
                   for w,scale in zip(self.slow,(1,.5))]
        self.fast=[np.zeros_like(w) for w in self.slow]
        self.trace=[np.zeros_like(w) for w in self.slow]
        self.params=transform(z)
        r=np.random.default_rng(np.random.SeedSequence([birth,3]))
        self.O=r.normal(0,1/np.sqrt(128),(257,128)).astype(np.float32)
        self.bias=np.zeros(257,np.float32)
        r=np.random.default_rng(np.random.SeedSequence([birth,4]))
        self.feedback=(r.choice((-1,1),(128,257))/np.sqrt(257)).astype(np.float32)
        r=np.random.default_rng(np.random.SeedSequence([birth,5]))
        self.end=np.zeros(88)
        self.end[r.choice(88,6,replace=False)]=r.uniform(.4,1,6)
        self.fe=np.zeros(88)
        self.h=np.zeros(128,np.float32)
        self.steps=0
        self.rescales=0

    def step(self,target=None,learn=True,fast_write=True,output_write=True,*,sensory_code=None):
        x=self.sensor.encode(self.fe*.95) if sensory_code is None else sensory_code
        pre=(x[self.inputs],self.h[self.rec])
        old=self.h.copy()
        activation=sum(((w+f)*u).sum(1) for w,f,u in zip(self.slow,self.fast,pre))
        self.h=.75*old+.25*np.tanh(activation)
        logits=self.O@self.h+self.bias
        exp=np.exp(logits-logits.max())
        prob=exp/exp.sum()
        if target is None:
            target=int(prob.argmax())
            learn=False
        loss=-np.log2(max(float(prob[target]),1e-30))
        if learn:
            error=-prob.copy()
            error[target]+=1
            signal=self.feedback@error
            u=min(self.steps/1023,1)
            warm=.1+.9*(3*u*u-2*u*u*u)
            if fast_write:
                for g,(a,b,c,d,eta,lam,decay,gain,beta,cap) in enumerate(self.params):
                    q=a*pre[g]*self.h[:,None]+b*pre[g]+c*self.h[:,None]+d
                    self.trace[g]=lam*self.trace[g]+(1-lam)*q
                    mod=np.tanh(gain*signal+beta)
                    raw=(1-decay)*self.fast[g]+eta*warm*mod[:,None]*self.trace[g]
                    norm=abs(raw).sum(1,keepdims=True)
                    self.rescales+=int((norm>cap).sum())
                    self.fast[g]=(raw/np.maximum(1,norm/cap)).astype(np.float32)
            if output_write:
                self.O+=.002*warm*np.outer(error,self.h)
                self.bias+=.002*warm*error
            self.steps+=1
        receptor=self.end if target==256 else self.sensor.R[target]
        self.fe=(self.fe*.95)[self.sensor.perm]+receptor
        assert np.isfinite(self.h).all() and np.isfinite(self.O).all()
        return target,loss,prob

    def fork(self):
        child=copy(self)
        for key in ("fast","trace"):
            setattr(child,key,[v.copy() for v in getattr(self,key)])
        for key in ("h","fe","O","bias"):
            setattr(child,key,getattr(self,key).copy())
        return child

    def generate(self):
        output=[]
        for _ in range(32):
            token,_,_=self.step(None)
            output.append(token)
            if token==256:
                break
        return output
