"""Cache only immutable, pre-symbol sensory activities on observed training streams."""
from functools import lru_cache
import numpy as np


def encode_batch(sensor, states):
    scales=states.max(axis=1,keepdims=True)
    normalized=states/np.where(scales>0,scales,1)
    raw=(sensor.B.T@np.ascontiguousarray(normalized[:,sensor.pn].T)).T
    out=np.zeros(raw.shape,dtype=np.uint8)
    for side,limit in zip((0,1),sensor.limits):
        indices=np.flatnonzero(sensor.side==side)
        values=raw[:,indices]
        threshold=np.partition(values,len(indices)-limit,axis=1)[:,len(indices)-limit:len(indices)-limit+1]
        greater=(values>threshold)&(values>0)
        tied=(values==threshold)&(values>0)
        selected=greater|(tied&(tied.cumsum(1)<=limit-greater.sum(1,keepdims=True)))
        out[:,indices]=selected
    return out


class Prepared:
    def __init__(self,symbols,net):
        self.symbols=tuple(symbols)
        self.packed=np.empty((len(symbols),648),dtype=np.uint8)
        state=np.zeros(88)
        for start in range(0,len(symbols),128):
            chunk=symbols[start:start+128]
            states=[]
            for token in chunk:
                states.append(state*.95)
                receptor=net.end if token==256 else net.sensor.R[token]
                state=(state*.95)[net.sensor.perm]+receptor
            codes=encode_batch(net.sensor,np.stack(states))
            self.packed[start:start+len(chunk)]=np.packbits(codes,axis=1)
        self.packed.flags.writeable=False

    def code(self,index):
        return np.unpackbits(self.packed[index],count=5177).astype(np.float32)
