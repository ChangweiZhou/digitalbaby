"""Real reduced ES and random search. Engineering data only."""
from hashlib import sha256
from functools import lru_cache
from prepared import Prepared
import json
from pathlib import Path
import resource
import time

import numpy as np

from learner import Learner,prior,sensor


def key(label):
    return int.from_bytes(sha256(("V219|ENGINEERING|"+label).encode()).digest()[:4],"big")


def make_data(label,limit):
    r=np.random.default_rng(key(label))
    records=[]
    for i in range(limit//16):
        a,b,c,d=r.choice(range(128,160),4,replace=False)
        p,q,z=r.choice(list(b"01234567"),3,replace=False)
        op=int(r.choice(list(b"XY")))
        swapped=i>=(limit//16)//2
        location=z if (op==88)^swapped else q
        raw=[79,a,p,79,b,q,op,a,b,77,a,z,81,b,location,256]
        records.append((raw,len(raw)-2))
    return records


@lru_cache(maxsize=4)
def prepared_life(label,limit):
    sense=sensor()
    net=Learner(prior(),key(label+"|birth"),sense)
    records=make_data(label,limit)
    symbols=[int(token) for raw,_ in records for token in raw]
    return records,Prepared(symbols,net)


def fitness(z,label,sense,limit):
    net=Learner(z,key(label+"|birth"),sense)
    records,prepared=prepared_life(label,limit)
    cursor=0
    scored=[]
    for record_index,(raw,position) in enumerate(records):
        for i,token in enumerate(raw):
            _,loss,_=net.step(int(token),sensory_code=prepared.code(cursor))
            cursor+=1
            if record_index>=3*len(records)//4 and i>=position and len(scored)<128:
                scored.append(loss)
    return float(np.mean(scored)),net,records


def run(generations=2,offspring=4,limit=640):
    assert offspring%2==0
    sense=sensor()
    center=prior()
    r=np.random.default_rng(21902)
    log=[]
    nominees=[]
    cpu=time.process_time()
    for generation in range(generations):
        worlds=[f"generation{generation}|life{j}" for j in range(2)]
        eps=r.normal(size=(offspring//2,20))
        gradient=np.zeros(20)
        es=[]
        for e in eps:
            pair=[]
            for sign in (1,-1):
                z=center+sign*.1*e
                values=[fitness(z,w,sense,limit)[0] for w in worlds]
                pair.append(float(np.mean(values)))
                es.append(dict(genome=z.tolist(),losses=values))
            gradient+=(pair[0]-pair[1])*e/(2*(offspring//2)*.1)
        center=center-.05*gradient
        random_candidates=[]
        for _ in range(offspring):
            z=prior()+r.normal(size=20)
            values=[fitness(z,w,sense,limit)[0] for w in worlds]
            random_candidates.append(dict(genome=z.tolist(),losses=values))
        winner=min(random_candidates,key=lambda c:np.mean(c["losses"]))
        val_label="fixed_validation"
        val_es=fitness(center,val_label,sense,limit)[0]
        val_rs=fitness(np.array(winner["genome"]),val_label,sense,limit)[0]
        nominees.append(dict(generation=generation,es=center.tolist(),rs=winner["genome"],
                             validation_es=val_es,validation_rs=val_rs))
        log.append(dict(generation=generation,worlds=worlds,es=es,random=random_candidates))
    selected={mode:min(nominees,key=lambda n:n["validation_"+mode])[mode] for mode in ("es","rs")}
    return dict(generations=generations,offspring=offspring,limit=limit,log=log,
                nominees=nominees,selected=selected,cpu_seconds=time.process_time()-cpu,
                peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                science="NOT_RUN")


if __name__=="__main__":
    Path("CYCLE2_TEST.json").write_text(json.dumps(run(),indent=2)+"\n")
