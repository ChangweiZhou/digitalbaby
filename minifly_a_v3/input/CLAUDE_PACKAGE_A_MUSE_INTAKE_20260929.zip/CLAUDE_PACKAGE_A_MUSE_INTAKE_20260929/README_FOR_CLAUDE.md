# Package A handoff: what is available, and what is not

This archive responds to Claude's request for Muse's Package A V2 source,
locks, receipts, stop record, and P3 failure record. **Those Muse-produced
files are not on this Mac.** An exhaustive filename search of the local
`Downloads` and `Documents/second_try` trees and the supplied attachments
found no `r_arms.py`, `z_arms.py`, `p_arms.py`, `run_all_science.py`,
`RECEIPTS_PROVISIONAL.json`, or `STOPPED_SCIENCE_RUN_20260929.md`. No Muse
Package A `SPEC_LOCK.md`, `SOURCE_LOCK.json`, or world-arm receipt directory
was found. Do not treat the included V2 zip as Muse's implemented V2 runner:
it is the original **input handoff**. Its archive listing has no Muse arm
source, Package A locks, or Package A receipts.

## Included and authenticated

- `MINIFLY_MUSE_A_7_V2_20260928.zip`: original input handoff, SHA-256
  `d76e54e982fc905c19b4e7e67ce959813efee5ceea7027fc9a75111cdbd59b8b`.
- `MINIFLY_MUSE_A_V3_CAUSAL_GATE_20260929.zip`: corrected causal-branch
  **scaffold**, SHA-256
  `c667ab51886e226a9e7f014af634f9e9fdb1e00ad384d0eabcfd64710972ab43`.
  It is not Muse's runner and contains no Muse science receipts.
- `ASSIGNMENT_MUSE_A.md`, `SHARED_PROTOCOL.md`, and
  `BIRTH_PORTABILITY_ADDENDUM.md`: readable copies of the binding assignment
  and protocol, also contained in the handoff/scaffold.
- `CLAUDE_INTAKE_458107b.md`: Claude's own intake record from commit
  `458107b`, included only to align the file inventory.
- `MUSE_STATUS_FROM_MESSAGES.md`: precise status reported by Muse in the
  conversation. This is **text-only testimony**, not a substitute for its
  machine receipts or source hashes.
- `CODEX_NEW_TECHNICAL_PROTOTYPE/`: separate **new** source, draft spec,
  tests and completed technical receipts made locally after Muse became
  unavailable. See its own `README.md` for exactly what passed and what is
  unfinished. These are not Muse V2 files or new science results.

## Consequence

The requested read-only V2 audit cannot be performed from this archive.
Muse's 13 technical receipts, source at stop, source lock, P3 technical
failure receipt, and immutable roster amendment remain unavailable. Do not
assert that V2's E1 is valid or that Muse's P3 failure has been independently
confirmed. V2's E3 branch defect is independently established by the V3
scaffold and by Claude's Package B receipt, but this does not authenticate
Muse's files.

If Package A must proceed without Muse's export, use Claude's already stated
fallback: a **new, separately named implementation** from the V3 scaffold,
first through world 190000 technical qualification only. Keep P3/P3_shuffle
unavailable unless independently qualified. Freeze the roster and source
before any new science decision. Preserve the program-wide `m=26` family and
show missing P3 comparisons as unavailable; do not silently recast it as
`m=22`. Existing Package B V2 E3 remains invalid.

I mistakenly began a separate local technical implementation before the user
clarified the task. Its process has been stopped. It is included only as an
explicitly isolated prototype to save Claude duplicate coding work; do not
mix its receipts with Muse V2 or Claude Package B, and do not treat it as a
source-locked science roster.
