# Package A V3 fresh implementation — status

This directory is a **new implementation workspace**, copied from the verified
V3 causal-branch scaffold. It is not Muse's V2 source, a resume of Muse's run,
or a scientific result. Muse's source, receipts, source lock, and roster
amendment were not available locally on 2026-09-29.

## Binding inputs

- Fixture: 600 records in world 190000 for technical qualification; science
  worlds 190001–190064 only after a new source lock.
- Five explicit branches: W, N_old_fact, N_old_rel, N_new_fact, N_new_rel.
- Every Full151 store must call `canonical_fresh_native()` separately before
  any clone, graph edit, byte, or teaching event. Merely cloning one newborn
  into four stores does not satisfy the prescribed birth procedure.
- Per-record, per-branch, per-store write decisions must be captured and
  checked independently; the aggregate V3 gate is necessary but insufficient.
- E1 is taught-key retention. Limited E3 is the never-reinforced old relation
  after delay and intervening learning; no general-intelligence claim follows.
- The original program-wide multiplicity is m=26. P3 and P3_shuffle are
  reported as technically unqualified from Muse's account, but the underlying
  failure receipt and amendment are unavailable. This fresh implementation
  cannot certify that historical finding.

## Intended technical roster

R1, R1_rand, R0, R3, R3_randtarget, R0_signed, Z2, Z2_rand, Z0_resource,
P1, P2, P4, P0. The six active candidate families are R1, R3, Z2, P1, P2,
P4; P3 remains explicitly unresolved and receives no silent replacement.
All technical arms will use world 190000. This roster is **provisional** until
the precise equations, controls, budgets, and source are locked.

## Current gate

The copied scaffold's full `verify_bundle.py` passed on pinned Python 3.11,
NumPy 2.2.6, SciPy 1.14.1, Numba 0.61.2, and pandas 2.2.3. It reported
`raw_B_match=true`, 600 fixture records, 20 correct branch decisions, 22
tamper rejections, and zero science trajectories. Package-local mechanism
source, full-life technical receipts, independent auditor, resource estimates,
and SOURCE_LOCK do not yet exist. No science runner should launch in this
state.
