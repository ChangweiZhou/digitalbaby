# Package A V3 candidate definitions — pre-technical draft

**Status: DRAFT, not a frozen SPEC_LOCK and not permission for science.**
The old Muse implementation and its parameter provenance are unavailable. A
fresh implementation must freeze each equation below *before* using technical
scores and must qualify its controls and budgets on world 190000. The source
and fixture supplied in V3 remain unchanged. The six candidate families below
are the provisional 13-arm roster recorded in
`PACKAGE_A_IMPLEMENTATION_STATUS.md`; P3 remains visible as unqualified and is
not silently replaced.

## Common causal interface

The output is emitted before its answer byte. W and four no-write branches see
exactly the same bytes and times. On fact records, stores 0–3 have a native
write opportunity; on relation records, only stores 0–1 do. Every store is
born by a separate call to `portable_birth.canonical_fresh_native()` before
any model clone or edit. A per-record, per-store ledger records *attempted
native writes*; actual zero updates are measured separately. On relation
held-out probes no feedback ever occurs. The limited E3 contrast is
W−N_old_rel at the final probe after a new cohort and a day. A raw or
canonical exact-cue lookup cannot answer those withheld pairs; a learned
one-bit symbol class rule can, so even a positive E3 is synthetic and narrow.

## R: two independently born four-store banks

Shared bank uses FE0; private bank uses the frozen last-four-visible-byte
address. Output uses the same fixed label-blind scales in candidate and
matched control. Both banks have the same native state budget. The private
bank's write rule differs by arm; the shared bank always follows the common
causal branch. All random decisions are SHA-256 streams keyed by world, arm,
branch, record, and store, with no hidden labels or future probe scores.

**R1 / R0 / R1_rand.** The pre-answer novelty statistic is a bounded distance
between the current private KC address and a rolling buffer of the most recent
24 private addresses. `novelty = 1−max_j Jaccard(x,x_j)`, with empty buffer
yielding 1. R1 permits a private write when novelty exceeds a threshold fixed
before any technical outcome. R0 permits all private writes. R1_rand places
the same number of private writes as R1 uniformly within each
stage×domain×answer stratum, using only R1's aggregate dose, never its chosen
records or prediction values. The buffer updates from the pre-answer code on
every presented record in every branch regardless of write permission.

**R3 / R0_signed / R3_randtarget.** All three use the same continuous signed
teaching interface to the inherited Full151 event. Let `p_j` be the shared
bank's pre-answer softmax over active outputs and `y_j` the observed answer's
one-hot target. R3 private punishment is
`r_j = clip(1/2 − (y_j−p_j)/2, 0, 1)`; R0_signed is the full target
`r_j=1−y_j` through *the same* continuous interface. R3_randtarget uses a
predeclared SHA-256 channel permutation of the target while keeping the same
residual magnitude, as a direction-specificity diagnostic. All private
teaching is contingent on the parent causal write branch. A zero residual
must produce no private plasticity, positive/negative residuals must reverse
direction, and the signed control must match ordinary binary Full151 at
targets 0 and 1.

## Z: existing KC→output coordinates only

Each of the four stores carries a bounded resource variable `q_k∈[0,1]` for
every originally writable KC coordinate. At each permitted write, compute
local conflict from pre-event fast and slow alpha states on that coordinate;
gate the inherited slow update and return the withheld amount to fast so total
native alpha is preserved. The resource state decays with model time and is
incremented by the local write magnitude, never by a cue ID or future label.
Z0_resource carries and updates exactly the same shadow state with gate=1.
Z2 uses the local conflict/resource gate. Z2_rand shuffles the Z2 gate across
eligible coordinates while matching the native slow L1 budget within side
and sign, using a separate fixed stream. No new address slots or writable
coordinates are allowed.

## P: fixed PN→KC partners, mutable existing weights

The support (`B.indices`, `B.indptr`) is byte-identical to canonical birth for
every arm, branch and time. The same pre-outcome PN activity and KC code are
captured from sensory events; no answer byte, teacher bit, item label or
scored correctness enters P plasticity. Updates occur at a fixed predeclared
sensory clock, including no-native-write branches. Each arm uses the same
initial graph, scalar step budget, positive weight bounds, per-KC norm rule,
state/trace budget and clone semantics. P0 carries the corresponding shadow
bookkeeping without changing weights. P1 adds local Hebbian coactivity on
existing edges; P2 uses Oja's `x_k p_i − x_k² w_ik` stable-weight term; P4
uses a signed predecessor/successor timing difference on the same edge. Every
graph edit is copy-on-write so probe clones and branch clones cannot mutate a
continuing sibling. P1/P2/P4 must each show a nonzero mechanism-specific
technical event and finite bounded weights on world 190000. No partner change
is permitted; this package tests weight plasticity, not the T/S topology
families in Package B.

**P implementation constants and clock, fixed before the P technical lives:**
one unsupervised update after each arriving answer-byte event (600 records per
life per store), from the FE0 PN activity and KC code captured *before* that
answer arrives. The answer identity and native write flag are not read by this
update. For each existing edge `(i,k)`, learning rate is `η=0.001`. P1 uses
`Δw=η p_i x_k`; P2 uses `Δw=η(p_i x_k−x_k² w)`; P4 uses
`Δw=η exp(−Δt/300s)(p_i,prev x_k−p_i x_k,prev)`, with the first update
zero. All updated weights are clipped to at least `10⁻⁹`, then rescaled so
each KC's sum of incoming weights exactly matches its canonical newborn sum.
P0 computes the same traces, coactivity and per-KC norm bookkeeping but
leaves B unchanged. These values are numerical-design constants, not selected
from world 190000 accuracy. The receipt separately reports the pre-normalised
local delta and actual weight change, which may differ because of the budget.

## Technical exit gate

For all 13 arms: independent-birth evidence; complete 600-record technical
life; literal aggregate V3 branch gate; separate per-record/store write audit;
pre-feedback-only mechanism event log; clone and replay parity; fixed support
where applicable; matched controls; deliberate mutation rejection; wall/RSS/
receipt budget measured on this Mac. No science world is run, or source lock
issued, until every implemented arm passes and the unresolved P3 roster and
program-wide m=26 treatment are written without contradiction.
