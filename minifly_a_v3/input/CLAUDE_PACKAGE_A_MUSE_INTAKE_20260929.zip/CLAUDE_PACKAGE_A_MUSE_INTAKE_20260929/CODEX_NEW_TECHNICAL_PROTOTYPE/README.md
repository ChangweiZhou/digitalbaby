# Separate Codex prototype, not Muse V2

This directory contains a **partial fresh Package A implementation** built
from the V3 scaffold. It is offered as source material for Claude's takeover,
not as a certified experiment or a continuation of Muse's run.

The source is an **overlay**, not a standalone tree: for inspection or tests,
extract the V3 scaffold to a fresh directory and copy this prototype's
`src/`, `tests/`, draft and technical receipts into that directory. Its
`src/paths.py` intentionally resolves the scaffold's frozen
`REFERENCE_SOURCE/` beside `src/`. Do not modify the archived V3 zip itself.

## Implemented and checked

- P0/P1/P2 fixed-partner PN→KC weight models completed one full **technical**
  world 190000 life each. P0/P1/P2 receipts are included unchanged. Four
  separate `canonical_fresh_native()` calls were made for each four-store
  birth. Each receipt has 12,000 per-store write decisions, 3,000 preteacher
  responses, 12,000 mechanism events, and a fixed-CSR-support audit.
- A plain four-store infrastructure baseline also completed world 190000.
- Independent per-record branch audit rejects the V2 `N_old_rel` defect,
  balanced per-store write swaps, wrong answers/times, and dropped rows.
- Independent P receipt audit rejects wrong support, event order, missing
  events, final-weight hash changes, and causal write corruption.
- R0/R1/R1_rand/R0_signed/R3/R3_randtarget two-bank source and R receipt
  auditor are present. R1 and R3 passed only **one-record unit tests**;
  no R full technical life was run.
- The isolated pinned environment passed the original V3 full
  `verify_bundle.py` before this code was added. The current source/tests
  passed 17 unit tests on Python 3.11.5, NumPy 2.2.6, SciPy 1.14.1,
  Numba 0.61.2 and pandas 2.2.3.

## Unfinished or stopped

- P4 started a full technical life but was stopped at the user's correction.
  **No P4 committed receipt** exists. Do not infer a P4 result.
- Z0_resource/Z2/Z2_rand have **not** been implemented.
- R full-life behavior and dose-matched controls are **not** qualified.
- The R and P equations live in `SPEC_CANDIDATE_DRAFT.md`, not a frozen
  `SPEC_LOCK.md`. Some R specifics may need review before source lock.
- No `SOURCE_LOCK.json`, full arm roster acceptance, resource budget,
  calibration qualification, science world, analysis, or final report exists.
- P3/P3_shuffle remain unavailable. This prototype does not independently
  reproduce Muse's claimed resource failure.

The `results/technical` receipts are technical development artifacts only.
If Claude uses this prototype, it must review equations and birth semantics,
finish the missing arms, run the full independent audit and all 13 technical
lives under one finalized source, then decide separately whether any science
execution is justified. Never merge these files into the Muse V2 audit as if
they came from Muse.
