import copy
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from audit_r import audit_r
from fixture import make_world
from test_branch_audit import synthetic


def r0_synthetic():
    r = synthetic()
    r["arm"] = "R0"
    r["write_ledger"] = [dict(x, bank="shared") for x in r["write_ledger"]] + [
        dict(x, bank="private") for x in r["write_ledger"]]
    fixture = make_world(190000)
    r["mechanism_events"] = {
        b: [{"world": 190000, "branch": b, "record": i, "stage": row["stage"],
             "domain": row["domain"], "answer": row["answer"],
             "causal_write_allowed": not (b == f"N_{row['stage']}_{'rel' if row['domain'] == 'relation' else 'fact'}"),
             "pre_answer_novelty": 1.0, "private_gate": True,
             "shared_prefeedback_values": [0.0] * 4, "private_residual": None}
            for i, row in enumerate(fixture["records"])]
        for b in ("W", "N_old_fact", "N_old_rel", "N_new_fact", "N_new_rel")}
    sha = "32a3726cb25a8255c1aef5696ff40aa303138c5d061a598004d2087d4da5f964"
    r["birth"] = [{"bank": bank, "store": j, "canonical_B_sha256": sha}
                  for bank in ("shared", "private") for j in range(4)]
    return r


class RAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.good = r0_synthetic()

    def test_good(self):
        self.assertTrue(audit_r(self.good)["pass"])

    def test_wrong_private_lesion(self):
        r = copy.deepcopy(self.good)
        row = next(x for x in r["write_ledger"] if x["bank"] == "private" and
                   x["branch"] == "N_old_rel" and x["domain"] == "relation" and
                   x["stage"] == "old" and x["store"] == 0)
        row["write"] = True
        with self.assertRaises(AssertionError):
            audit_r(r)


if __name__ == "__main__":
    unittest.main()
