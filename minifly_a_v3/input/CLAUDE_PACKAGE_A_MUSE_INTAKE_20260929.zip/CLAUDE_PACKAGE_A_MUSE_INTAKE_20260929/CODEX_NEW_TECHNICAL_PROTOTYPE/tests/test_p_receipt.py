import copy
import gzip
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from audit_p import audit_p


class PReceiptTamperTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        receipt = ROOT / "results" / "technical" / "P0" / "190000.json.gz"
        with gzip.open(receipt, "rt") as stream:
            cls.good = json.load(stream)

    def reject(self, edit):
        bad = copy.deepcopy(self.good)
        edit(bad)
        with self.assertRaises(AssertionError):
            audit_p(bad)

    def test_good(self):
        self.assertTrue(audit_p(self.good)["pass"])

    def test_wrong_support(self):
        self.reject(lambda r: r["mechanism_events"]["W"][9].__setitem__("structure_sha256", "0" * 64))

    def test_wrong_event(self):
        self.reject(lambda r: r["mechanism_events"]["W"][9].__setitem__("event", 99))

    def test_dropped_event(self):
        self.reject(lambda r: r["mechanism_events"]["W"].pop())

    def test_wrong_final_weight_hash(self):
        self.reject(lambda r: r["end_B"]["W"][0].__setitem__("weights", "0" * 64))

    def test_bad_relation_lesion(self):
        self.reject(lambda r: next(x for x in r["write_ledger"] if x["branch"] == "N_old_rel" and
                                   x["stage"] == "old" and x["domain"] == "relation" and
                                   x["store"] == 0).__setitem__("write", True))


if __name__ == "__main__":
    unittest.main()
