import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import paths  # noqa: F401
from common_platform import output_before_teacher
from fixture import DT, make_world
from r_model import from_fresh_births


class RModelTests(unittest.TestCase):
    def one_record(self, arm):
        actor, births = from_fresh_births(arm)
        self.assertEqual(len(births), 8)
        world = make_world(190000)
        row = world["records"][0]
        actor.set_record_context(190000, "W", 0, row["stage"], row["domain"])
        cue = bytes.fromhex(row["cue_hex"])
        emitted, values, t, domain = output_before_teacher(actor, cue, 0.0)
        self.assertEqual(t, 12 * DT)
        self.assertEqual(len(values), 4)
        self.assertIn(emitted, b"0123")
        before = actor.digests()
        actor.teach(row["answer"], t, domain, write=True)
        self.assertNotEqual(before, actor.digests())
        self.assertEqual(len(actor.shared.write_ledger), 4)
        self.assertEqual(len(actor.private.write_ledger), 4)
        self.assertEqual(len(actor.mechanism_events), 1)
        clone = actor.clone()
        self.assertEqual(clone.digests(), actor.digests())

    def test_r1_one_record(self):
        self.one_record("R1")

    def test_r3_one_record(self):
        self.one_record("R3")


if __name__ == "__main__":
    unittest.main()
