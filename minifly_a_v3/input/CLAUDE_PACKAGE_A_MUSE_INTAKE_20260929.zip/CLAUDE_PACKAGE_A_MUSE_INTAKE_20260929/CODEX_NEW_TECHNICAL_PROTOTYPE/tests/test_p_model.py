import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import paths  # noqa: F401
import portable_birth as birth
from p_model import PBrain, csr_data_digest, csr_structure_digest


class PModelTests(unittest.TestCase):
    def make(self, arm):
        base, _ = birth.canonical_fresh_native()
        return PBrain.from_canonical_newborn(base, arm)

    def test_support_clone_and_updates(self):
        p = np.zeros(302)
        x = np.zeros(5177)
        p[0:100] = 0.5
        x[0:150] = 1.0
        for arm in ("P0", "P1", "P2", "P4"):
            brain = self.make(arm)
            support = csr_structure_digest(brain.fly.m.B)
            prior = csr_data_digest(brain.fly.m.B)
            brain._sensory_update(p, x, 0.0)
            brain._sensory_update(np.roll(p, 1), np.roll(x, 1), 165.0)
            self.assertEqual(csr_structure_digest(brain.fly.m.B), support)
            self.assertTrue(np.isfinite(brain.fly.m.B.data).all())
            self.assertEqual(csr_data_digest(brain.fly.m.B) == prior, arm == "P0")
            child = brain.clone()
            self.assertEqual(child.state_digest(), brain.state_digest())
            self.assertIsNot(child.fly.m.B, brain.fly.m.B)


if __name__ == "__main__":
    unittest.main()
