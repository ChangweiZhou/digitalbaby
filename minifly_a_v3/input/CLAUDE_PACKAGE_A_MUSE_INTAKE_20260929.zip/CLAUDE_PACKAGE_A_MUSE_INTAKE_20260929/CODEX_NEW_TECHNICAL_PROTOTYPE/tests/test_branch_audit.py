"""Independent schedule mutations; no learner trajectory is run here."""
import copy
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))
import audit_branch as audit
from fixture import DT, RECORD_SECONDS, make_world


def synthetic(world=190000):
    fixture = make_world(world)
    first, ledger = [], []
    counts = {b: {d: 0 for d in ("old_fact", "old_relation", "new_fact", "new_relation")}
              for b in audit.BRANCHES}
    for i, rec in enumerate(fixture["records"]):
        stage, domain, answer = rec["stage"], rec["domain"], rec["answer"]
        when = i * RECORD_SECONDS + (86400 if stage == "new" else 0) + 12 * DT
        for branch in audit.BRANCHES:
            first.append({"record": i, "branch": branch, "teacher_at": when})
            allowed = audit.BLOCKED[branch] != (stage, domain)
            for j in range(4):
                write = allowed and (domain == "fact" or j < 2)
                ledger.append({"world": world, "record": i, "branch": branch,
                               "bank": "native", "store": j, "stage": stage,
                               "domain": domain, "answer": answer,
                               "teacher_at": when, "write": write})
                counts[branch][f"{stage}_{domain}"] += int(write)
    return {"world": world, "fixture_digest": fixture["digest"],
            "branches": list(audit.BRANCHES), "first": first,
            "write_ledger": ledger, "writes": counts}


class BranchAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.good = synthetic()

    def assert_rejected(self, mutator):
        bad = copy.deepcopy(self.good)
        mutator(bad)
        with self.assertRaises(AssertionError):
            audit.audit_receipt(bad)

    def test_good(self):
        self.assertTrue(audit.audit_receipt(self.good)["pass"])

    def test_restored_v2_relation_writes(self):
        def mutate(r):
            for row in r["write_ledger"]:
                if row["branch"] == "N_old_rel" and row["stage"] == "old" and row["domain"] == "relation":
                    row["write"] = row["store"] < 2
            r["writes"]["N_old_rel"]["old_relation"] = 288
        self.assert_rejected(mutate)

    def test_balanced_wrong_decisions(self):
        def mutate(r):
            candidates = [x for x in r["write_ledger"] if x["branch"] == "W" and
                          x["stage"] == "old" and x["domain"] == "relation"]
            next(x for x in candidates if x["store"] == 0)["write"] = False
            next(x for x in candidates if x["store"] == 2)["write"] = True
            # Same old-relation aggregate, but wrong per-store decisions.
        self.assert_rejected(mutate)

    def test_wrong_teacher_time(self):
        self.assert_rejected(lambda r: r["write_ledger"][10].__setitem__(
            "teacher_at", r["write_ledger"][10]["teacher_at"] + 1))

    def test_wrong_answer(self):
        self.assert_rejected(lambda r: r["write_ledger"][10].__setitem__("answer", 255))

    def test_missing_row(self):
        self.assert_rejected(lambda r: r["write_ledger"].pop())


if __name__ == "__main__":
    unittest.main()
