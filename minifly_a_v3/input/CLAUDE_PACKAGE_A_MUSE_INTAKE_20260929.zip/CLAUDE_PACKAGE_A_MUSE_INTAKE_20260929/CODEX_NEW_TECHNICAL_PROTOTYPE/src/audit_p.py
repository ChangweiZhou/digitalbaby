"""Independent structural and event-order audit of P technical receipts."""
from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

from audit_branch import BRANCHES, audit_receipt


def audit_p(receipt: dict) -> dict:
    arm = receipt.get("arm")
    if arm not in ("P0", "P1", "P2", "P4") or receipt.get("world") != 190000:
        raise AssertionError("wrong P arm or technical world")
    audit_receipt(receipt)
    births = receipt.get("birth")
    if not isinstance(births, list) or len(births) != 4 or [b.get("store") for b in births] != list(range(4)):
        raise AssertionError("four separately recorded newborns missing")
    if len({b["canonical_B_sha256"] for b in births}) != 1 or (
            births[0]["canonical_B_sha256"] != "32a3726cb25a8255c1aef5696ff40aa303138c5d061a598004d2087d4da5f964"):
        raise AssertionError("canonical birth B mismatch")
    support = births[0]["structure_sha256"]
    initial_weights = births[0]["birth_weight_sha256"]
    if any(b["structure_sha256"] != support or b["birth_weight_sha256"] != initial_weights for b in births):
        raise AssertionError("P stores began from different graphs")
    end = receipt.get("end_B")
    events = receipt.get("mechanism_events")
    if not isinstance(end, dict) or set(end) != set(BRANCHES) or not isinstance(events, dict) or set(events) != set(BRANCHES):
        raise AssertionError("P branch result roster incomplete")
    changed_w = 0
    for branch in BRANCHES:
        rows = events[branch]
        if len(rows) != 600 * 4:
            raise AssertionError(f"P event count wrong for {branch}")
        for i in range(600):
            for j in range(4):
                row = rows[i * 4 + j]
                if row.get("context", [None] * 3)[1:3] != [branch, i] or row.get("store") != j or (
                        row.get("event") != i + 1 or row.get("arm") != arm or
                        row.get("structure_sha256") != support):
                    raise AssertionError(f"P event identity/support wrong: {branch}/{i}/{j}")
                for field in ("coactivity_l1", "local_delta_l1", "actual_weight_delta_l1"):
                    value = row.get(field)
                    if not isinstance(value, (float, int)) or not math.isfinite(value) or value < 0:
                        raise AssertionError(f"nonfinite or negative P event {field}")
                if arm == "P0" and (row["local_delta_l1"] != 0 or row["actual_weight_delta_l1"] != 0):
                    raise AssertionError("P0 changed input weights")
                if arm == "P4" and i == 0 and row["local_delta_l1"] != 0:
                    raise AssertionError("P4 first event used nonexistent predecessor")
        final = end[branch]
        if not isinstance(final, list) or len(final) != 4:
            raise AssertionError("end graph roster incomplete")
        for j, row in enumerate(final):
            if row.get("structure") != support or row.get("events") != 600 or (
                    row.get("weights") != rows[-4 + j]["weights_sha256"]):
                raise AssertionError("P final graph does not match last event")
            changed_w += int(branch == "W" and row["weights"] != initial_weights)
            if arm == "P0" and row["weights"] != initial_weights:
                raise AssertionError("P0 final weights changed")
    if arm != "P0" and changed_w != 4:
        raise AssertionError("candidate failed to change all four W store graphs")
    return {"pass": True, "arm": arm, "world": 190000,
            "events": 600 * 4 * 5, "changed_W_stores": changed_w,
            "support_sha256": support}


def load(path: Path):
    with gzip.open(path, "rt") as stream:
        return json.load(stream)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    print(json.dumps(audit_p(load(args.receipt)), indent=2))
