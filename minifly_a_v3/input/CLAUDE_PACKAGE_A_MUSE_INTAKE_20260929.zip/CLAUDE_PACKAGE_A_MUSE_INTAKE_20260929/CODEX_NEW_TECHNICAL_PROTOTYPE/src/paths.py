"""Package-local imports; the frozen V3 reference source is read-only."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / "REFERENCE_SOURCE" / "MINIFLY_THREE_MECHANISM_ROUND_20260928"
sys.dont_write_bytecode = True
for path in (ROOT, REF, ROOT / "REFERENCE_SOURCE" / "BYTE_CORE_V9",
             ROOT / "REFERENCE_SOURCE" / "FULL151_VISIBLE_CONTEXT_BRIDGE_20260927"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))
