"""Package-A R technical world only, with write-once full-life receipts."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import resource
import time
from collections import defaultdict

import paths
from common_platform import BRANCHES, branch_allows, run_fourstore_life
from audit_r import audit_r
from r_model import R_ARMS, _hash_rank, from_fresh_births
from fixture import make_world


def receipt_path(arm):
    return paths.ROOT / "results" / "technical" / arm / "190000.json.gz"


def random_gate_schedule():
    source = receipt_path("R1")
    if not source.exists():
        raise RuntimeError("R1_rand requires committed R1 technical receipt")
    raw = source.read_bytes()
    r = json.loads(gzip.decompress(raw))
    if r.get("arm") != "R1" or r.get("world") != 190000 or not audit_r(r)["pass"]:
        raise AssertionError("R1 gate source failed technical audit")
    fixture = make_world(190000)
    schedules = {}
    for branch in BRANCHES:
        buckets = defaultdict(list)
        counts = defaultdict(int)
        for i, row in enumerate(fixture["records"]):
            if branch_allows(branch, row["stage"], row["domain"]):
                key = (row["stage"], row["domain"], row["answer"])
                buckets[key].append(i)
                counts[key] += int(r["mechanism_events"][branch][i]["private_gate"])
        selected = set()
        for key, indices in buckets.items():
            ranks = sorted(indices, key=lambda i: _hash_rank("R1-rand-v1", 190000,
                                                             branch, *key, i))
            selected.update(ranks[:counts[key]])
        schedules[branch] = {i: i in selected for i in range(600)}
    return schedules, hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("arm", choices=R_ARMS)
    args = parser.parse_args()
    arm = args.arm
    out = receipt_path(arm)
    if out.exists():
        raise RuntimeError(f"receipt already committed: {out}")
    start = time.monotonic()
    schedule, parent_hash = (random_gate_schedule() if arm == "R1_rand" else (None, None))
    actor, births = from_fresh_births(arm, random_gates=schedule)
    doc = run_fourstore_life(190000, actor, technical=True)
    if len(actor.branch_children) != len(BRANCHES):
        raise AssertionError("R branch clone registry mismatch")
    doc["arm"] = arm
    doc["birth"] = births
    doc["random_gate_parent_sha256"] = parent_hash
    doc["write_ledger"] = [row for child in actor.branch_children
                           for row in child.shared.write_ledger + child.private.write_ledger]
    doc["source_sha256"] = {p.relative_to(paths.ROOT).as_posix():
                             hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in sorted((paths.ROOT / "src").glob("*.py"))}
    doc["resources"] = {"wall_s": time.monotonic() - start,
                        "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    doc["audit_R"] = audit_r(doc)
    packed = gzip.compress(json.dumps(doc, sort_keys=True, separators=(",", ":"),
                                      allow_nan=False).encode(), compresslevel=5)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + f".pending-{os.getpid()}")
    with open(tmp, "xb") as f:
        f.write(packed)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.link(tmp, out)
    finally:
        tmp.unlink()
    print(json.dumps({"arm": arm, "world": 190000, "audit": doc["audit_R"],
                      "wall_s": doc["resources"]["wall_s"],
                      "receipt": str(out),
                      "receipt_sha256": hashlib.sha256(packed).hexdigest()}), flush=True)


if __name__ == "__main__":
    main()
