"""Fresh P0/P1/P2/P4 full technical lives; never runs science worlds."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import resource
import time

import paths
from audit_branch import audit_receipt
from branch_ledger import ledgers_from_actor
from common_platform import BRANCHES, run_fourstore_life
from p_model import ARMS, PBrain, PFourStore, csr_data_digest, csr_structure_digest
import portable_birth as birth


def build(arm):
    stores, receipts = [], []
    for j in range(4):
        model, raw = birth.canonical_fresh_native()
        from brain_byte import bc
        canonical = bc.v88().sparse_digest(model.fly.m.B)
        if canonical != birth.EXPECTED_B:
            raise AssertionError("birth B mismatch")
        model = PBrain.from_canonical_newborn(model, arm)
        stores.append(model)
        receipts.append({"store": j, "raw_B_sha256": raw,
                         "canonical_B_sha256": canonical,
                         "structure_sha256": model.p_structure,
                         "birth_weight_sha256": model.p_birth_data})
    if len({id(m.fly.m.B) for m in stores}) != 4:
        raise AssertionError("P newborn B identity shared")
    return PFourStore(stores), receipts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("arm", choices=ARMS)
    args = parser.parse_args()
    arm = args.arm
    out = paths.ROOT / "results" / "technical" / arm / "190000.json.gz"
    if out.exists():
        raise RuntimeError(f"receipt already committed: {out}")
    start = time.monotonic()
    actor, births = build(arm)
    doc = run_fourstore_life(190000, actor, technical=True)
    doc["arm"] = arm
    doc["birth"] = births
    doc["write_ledger"] = ledgers_from_actor(actor, BRANCHES)
    doc["end_B"] = {branch: [{"structure": csr_structure_digest(m.fly.m.B),
                              "weights": csr_data_digest(m.fly.m.B),
                              "events": m.p_events} for m in child.stores]
                    for branch, child in zip(BRANCHES, actor.branch_children, strict=True)}
    doc["source_sha256"] = {p.relative_to(paths.ROOT).as_posix():
                             hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in sorted((paths.ROOT / "src").glob("*.py"))}
    doc["resources"] = {"wall_s": time.monotonic() - start,
                        "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    doc["audit_branch"] = audit_receipt(doc)
    if any(row["structure"] != births[0]["structure_sha256"]
           for branch in doc["end_B"].values() for row in branch):
        raise AssertionError("P support changed")
    if arm == "P0" and any(row["weights"] != births[0]["birth_weight_sha256"]
                            for branch in doc["end_B"].values() for row in branch):
        raise AssertionError("P0 changed B weights")
    if arm != "P0" and not any(row["weights"] != births[0]["birth_weight_sha256"]
                                for row in doc["end_B"]["W"]):
        raise AssertionError("P candidate made no weight change")
    raw = json.dumps(doc, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    packed = gzip.compress(raw, compresslevel=5)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + f".pending-{os.getpid()}")
    with open(tmp, "xb") as f:
        f.write(packed)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.link(tmp, out)
    finally:
        tmp.unlink()
    print(json.dumps({"arm": arm, "world": 190000, "wall_s": doc["resources"]["wall_s"],
                      "audit": doc["audit_branch"], "receipt": str(out),
                      "receipt_sha256": hashlib.sha256(packed).hexdigest()}), flush=True)


if __name__ == "__main__":
    main()
