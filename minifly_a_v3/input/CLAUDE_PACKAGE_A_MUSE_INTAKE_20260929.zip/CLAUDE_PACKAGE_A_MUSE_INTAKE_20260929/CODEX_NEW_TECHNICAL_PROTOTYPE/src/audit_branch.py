"""Independent per-record branch/exposure auditor for Package A.

This module deliberately does not import runner, branch_ledger, or the
platform's branch_allows. It derives expected decisions from literal branch
names and the frozen fixture record list.
"""
from __future__ import annotations

import math
import paths  # noqa: F401
from fixture import DT, RECORD_SECONDS, make_world

BRANCHES = ("W", "N_old_fact", "N_old_rel", "N_new_fact", "N_new_rel")
BLOCKED = {"W": None, "N_old_fact": ("old", "fact"),
           "N_old_rel": ("old", "relation"),
           "N_new_fact": ("new", "fact"),
           "N_new_rel": ("new", "relation")}


def audit_receipt(receipt: dict, *, banks=("native",)) -> dict:
    world = receipt.get("world")
    if type(world) is not int:
        raise AssertionError("world ID missing")
    fixture = make_world(world)
    if receipt.get("fixture_digest") != fixture["digest"]:
        raise AssertionError("fixture digest mismatch")
    if receipt.get("branches") != list(BRANCHES):
        raise AssertionError("branch roster mismatch")
    first = receipt.get("first")
    if not isinstance(first, list) or len(first) != 600 * 5:
        raise AssertionError("first-response roster incomplete")
    by_first = {(r["record"], r["branch"]): r for r in first}
    if len(by_first) != 3000:
        raise AssertionError("duplicate first response")
    ledger = receipt.get("write_ledger")
    if not isinstance(ledger, list) or len(ledger) != 600 * 5 * 4 * len(banks):
        raise AssertionError("per-store write ledger incomplete")
    by_key = {(r["record"], r["branch"], r["bank"], r["store"]): r for r in ledger}
    if len(by_key) != len(ledger):
        raise AssertionError("duplicate per-store write decision")
    counts = {b: {d: 0 for d in ("old_fact", "old_relation", "new_fact", "new_relation")}
              for b in BRANCHES}
    for i, rec in enumerate(fixture["records"]):
        stage, domain, answer = rec["stage"], rec["domain"], rec["answer"]
        when = i * RECORD_SECONDS + (86400 if stage == "new" else 0) + 12 * DT
        for branch in BRANCHES:
            f = by_first.get((i, branch))
            if f is None or not math.isclose(float(f["teacher_at"]), when, abs_tol=1e-8):
                raise AssertionError(f"first response/teacher time wrong at {i}/{branch}")
            allowed = BLOCKED[branch] != (stage, domain)
            for bank in banks:
                for j in range(4):
                    r = by_key.get((i, branch, bank, j))
                    expected_write = allowed and (domain == "fact" or j < 2)
                    if r is None or any((r.get("world") != world, r.get("record") != i,
                                         r.get("branch") != branch, r.get("bank") != bank,
                                         r.get("store") != j, r.get("stage") != stage,
                                         r.get("domain") != domain, r.get("answer") != answer,
                                         r.get("write") is not expected_write,
                                         not math.isclose(float(r.get("teacher_at", -1)), when,
                                                          abs_tol=1e-8))):
                        raise AssertionError(f"write decision wrong at {i}/{branch}/{bank}/{j}")
                    if bank == banks[0] and expected_write:
                        counts[branch][f"{stage}_{domain}"] += 1
    if receipt.get("writes") != counts:
        raise AssertionError("aggregate counts differ from independently audited ledger")
    return {"pass": True, "world": world, "rows": len(ledger), "first": len(first),
            "branches": list(BRANCHES), "banks": list(banks)}
