"""One Package-A baseline technical life on the reserved world 190000 only.

This is an infrastructure gate, not a candidate mechanism and not science.
Four independent canonical_fresh_native() calls occur before any cloning.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import platform
import resource
import sys
import time
from pathlib import Path

import paths
from audit_branch import audit_receipt
from branch_ledger import LedgerFourStore, ledgers_from_actor
import portable_birth as birth
from common_platform import BRANCHES, run_fourstore_life

ROOT = paths.ROOT
OUT = ROOT / "results" / "technical" / "P0_BASELINE_INFRA" / "190000.json.gz"


def build_actor():
    stores, births = [], []
    for j in range(4):
        model, raw_digest = birth.canonical_fresh_native()
        canonical_digest = model.fly.m.B
        from brain_byte import bc
        actual = bc.v88().sparse_digest(canonical_digest)
        if actual != birth.EXPECTED_B:
            raise AssertionError("canonical newborn B mismatch")
        stores.append(model)
        births.append({"store": j, "raw_B_sha256": raw_digest,
                       "canonical_B_sha256": actual,
                       "newborn_state_sha256": model.state_digest()})
    if len({id(m) for m in stores}) != 4 or len({id(m.fly) for m in stores}) != 4 or (
            len({id(m.fly.m.B) for m in stores}) != 4):
        raise AssertionError("newborn stores share mutable identity")
    if len({b["newborn_state_sha256"] for b in births}) != 1:
        raise AssertionError("birth states differ")
    return LedgerFourStore(stores), births


def atomic_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".pending-{os.getpid()}")
    with open(tmp, "xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(tmp, path)
    finally:
        tmp.unlink()


def main():
    if OUT.exists():
        raise RuntimeError("technical baseline receipt already committed")
    start = time.monotonic()
    actor, births = build_actor()
    built_s = time.monotonic() - start
    doc = run_fourstore_life(190000, actor, technical=True)
    doc["arm"] = "P0_BASELINE_INFRA"
    doc["write_ledger"] = ledgers_from_actor(actor, BRANCHES)
    doc["birth"] = births
    doc["source_sha256"] = {
        p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT / "src").glob("*.py"))}
    doc["resources"] = {
        "build_s": built_s, "total_wall_s": time.monotonic() - start,
        "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "host": platform.platform(), "python": sys.version.split()[0]}
    audit = audit_receipt(doc)
    doc["audit"] = audit
    raw = json.dumps(doc, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    packed = gzip.compress(raw, compresslevel=5)
    doc["resources"]["receipt_bytes"] = len(packed)
    # Re-serialize once with final byte count; audit does not depend on it.
    packed = gzip.compress(json.dumps(doc, sort_keys=True, separators=(",", ":"),
                                      allow_nan=False).encode(), compresslevel=5)
    atomic_new(OUT, packed)
    print(json.dumps({"arm": doc["arm"], "world": 190000,
                      "audit": audit, "birth_calls": len(births),
                      "wall_s": doc["resources"]["total_wall_s"],
                      "receipt": str(OUT), "receipt_sha256": hashlib.sha256(packed).hexdigest()}))


if __name__ == "__main__":
    main()
