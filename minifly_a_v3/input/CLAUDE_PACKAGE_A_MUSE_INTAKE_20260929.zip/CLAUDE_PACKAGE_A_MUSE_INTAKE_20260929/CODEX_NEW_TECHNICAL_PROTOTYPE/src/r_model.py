"""Two-bank candidate mechanisms with matched common output and birth.

The shared FE0 bank always receives allowed native writes. The private
visible-context bank differs only in its declared write rule. Predictions,
novelty and random gates are computed before the observed answer byte.
"""
from __future__ import annotations

import hashlib
import math
import numpy as np

import paths  # noqa: F401
from brain_byte import bc
from common_platform import CHANNELS, clone_model
from branch_ledger import LedgerFourStore
import content_model

R_ARMS = ("R0", "R1", "R1_rand", "R0_signed", "R3", "R3_randtarget")
SCALE_SHARED = 1.6010790608465912
SCALE_PRIVATE = 1.3304255978395276
NOVELTY_WINDOW = 24
NOVELTY_THRESHOLD = 0.20


def _hash_rank(*parts):
    return hashlib.sha256("|".join(map(str, parts)).encode()).digest()


def _signed_teach(model, punishment: float, t: float, *, write: bool):
    if not 0.0 <= punishment <= 1.0 or not math.isfinite(punishment):
        raise ValueError("signed teacher outside [0,1]")
    if model.pending_x is None or model.pending_t is None or abs(float(t) - model.pending_t) > 1e-9:
        raise AssertionError("signed teacher not immediately after answer")
    dt = model.pending_t - model.brain_t
    if dt < -1e-9:
        raise AssertionError("signed teacher moved time backwards")
    model.fly.event(max(0.0, dt), model.pending_x, float(punishment), bool(write))
    model.brain_t = model.pending_t
    model.teach_seen += 1
    model.pending_x = None
    model.pending_t = None


class SignedFourStore(LedgerFourStore):
    def __init__(self, stores, *, register_children=True):
        super().__init__(stores, bank="private", register_children=register_children)

    def clone(self):
        out = SignedFourStore([clone_model(m) for m in self.stores], register_children=False)
        out.context = self.context
        out.mechanism_events = list(self.mechanism_events)
        if self.register_children:
            self.branch_children.append(out)
        return out

    def teach_signed(self, answer: int, t: float, domain: str, *, allowed: bool,
                     punishments: list[float], residual: list[float]):
        if self.context is None:
            raise AssertionError("signed teacher missing context")
        world, branch, index, stage, declared = self.context
        if domain != declared or answer not in CHANNELS:
            raise AssertionError("signed teacher/domain mismatch")
        active = 4 if domain == "fact" else 2
        if len(punishments) != active or len(residual) != active:
            raise AssertionError("signed teacher vector size mismatch")
        for m in self.stores:
            m.byte(answer, t, learn=False)
        for j, m in enumerate(self.stores):
            write = bool(allowed and j < active and residual[j] != 0)
            _signed_teach(m, punishments[j] if j < active else 0.5, t, write=write)
            self.write_ledger.append({"world": world, "branch": branch,
                                      "record": index, "stage": stage, "domain": domain,
                                      "bank": "private", "store": j, "write": write,
                                      "answer": answer, "teacher_at": float(t),
                                      "punishment": punishments[j] if j < active else 0.5,
                                      "residual": residual[j] if j < active else 0.0})


class RBank:
    def __init__(self, shared: LedgerFourStore, private: LedgerFourStore, arm: str,
                 *, random_gates=None, register_children=True):
        if arm not in R_ARMS or len(shared.stores) != 4 or len(private.stores) != 4:
            raise ValueError("invalid R bank construction")
        self.shared, self.private, self.arm = shared, private, arm
        self.random_gates = {} if random_gates is None else random_gates
        self.register_children = register_children
        self.branch_children = []
        self.context = None
        self.pred_shared = None
        self.pred_combined = None
        self.current_x = None
        self.recent = []
        self.mechanism_events = []

    def clone(self):
        out = RBank(self.shared.clone(), self.private.clone(), self.arm,
                    random_gates=self.random_gates, register_children=False)
        out.context = self.context
        out.pred_shared = None if self.pred_shared is None else list(self.pred_shared)
        out.pred_combined = None if self.pred_combined is None else list(self.pred_combined)
        out.current_x = None if self.current_x is None else self.current_x.copy()
        out.recent = [x.copy() for x in self.recent]
        out.mechanism_events = list(self.mechanism_events)
        if self.register_children:
            self.branch_children.append(out)
        return out

    def digests(self):
        # The novelty buffer is learned unsupervised state. Include it so a
        # read-only probe can detect accidental mutation of continuing life.
        h = hashlib.sha256()
        for x in self.recent:
            h.update(np.packbits(x.astype(np.uint8)).tobytes())
        return self.shared.digests() + self.private.digests() + [h.hexdigest()]

    def set_record_context(self, world, branch, index, stage, domain):
        self.context = (int(world), branch, int(index), stage, domain)
        self.shared.set_record_context(world, branch, index, stage, domain)
        self.private.set_record_context(world, branch, index, stage, domain)
        self.pred_shared = self.pred_combined = self.current_x = None

    def feed(self, b, t):
        self.shared.feed(b, t)
        self.private.feed(b, t)

    def values(self, t):
        before = self.digests()
        s, p = self.shared.values(t), self.private.values(t)
        combined = [s[j] / SCALE_SHARED + p[j] / SCALE_PRIVATE for j in range(4)]
        if self.context is not None:
            # A pre-answer private address, before the outcome byte arrives.
            model = self.private.stores[0]
            fe = model.fe.clone()
            fe.advance(float(t))
            self.current_x = np.asarray(model.model.encode_sparse(model.fly.m, fe.read()),
                                        dtype=np.uint8)
            self.pred_shared = list(s)
            self.pred_combined = list(combined)
        if self.digests() != before or not all(math.isfinite(v) for v in combined):
            raise AssertionError("R value read mutated continuing state")
        return combined

    def _novelty(self):
        if self.current_x is None:
            raise AssertionError("R pre-answer KC address missing")
        if not self.recent:
            return 1.0
        a = self.current_x.astype(bool)
        similarities = []
        for prior in self.recent:
            b = prior.astype(bool)
            union = np.count_nonzero(a | b)
            similarities.append(np.count_nonzero(a & b) / union if union else 1.0)
        return 1.0 - max(similarities)

    def _active_probabilities(self, domain):
        active = 4 if domain == "fact" else 2
        logits = np.asarray(self.pred_shared[:active], dtype=np.float64) / SCALE_SHARED
        exp = np.exp(logits - logits.max())
        return exp / exp.sum()

    def teach(self, answer, t, domain, *, write):
        if self.context is None or self.pred_shared is None or self.current_x is None:
            raise AssertionError("R teaching lacks a pre-answer prediction")
        world, branch, index, stage, declared = self.context
        if domain != declared or answer not in CHANNELS:
            raise AssertionError("R teacher mismatch")
        active = 4 if domain == "fact" else 2
        target = CHANNELS.index(answer)
        novelty = self._novelty()
        gate = True
        if self.arm == "R1":
            gate = novelty > NOVELTY_THRESHOLD
        elif self.arm == "R1_rand":
            gate = bool(self.random_gates[branch][index])
        self.shared.teach(answer, t, domain, write=write)
        residual = None
        if self.arm in ("R0_signed", "R3", "R3_randtarget"):
            p = self._active_probabilities(domain)
            y = np.zeros(active, dtype=np.float64)
            y[target] = 1.0
            residual = y - p
            if self.arm == "R0_signed":
                punishment = 1.0 - y
                dose = np.ones(active)
            else:
                if self.arm == "R3_randtarget":
                    order = sorted(range(active), key=lambda j: _hash_rank(
                        "R3-randtarget-v1", world, branch, index, j))
                    residual = residual[order]
                punishment = np.clip(0.5 - residual / 2.0, 0.0, 1.0)
                dose = residual
            self.private.teach_signed(answer, t, domain, allowed=write,
                                      punishments=list(map(float, punishment)),
                                      residual=list(map(float, dose)))
        else:
            self.private.teach(answer, t, domain, write=write and gate)
        self.recent.append(self.current_x.copy())
        if len(self.recent) > NOVELTY_WINDOW:
            self.recent.pop(0)
        self.mechanism_events.append({"world": world, "branch": branch, "record": index,
                                      "stage": stage, "domain": domain, "answer": answer,
                                      "pre_answer_novelty": novelty,
                                      "causal_write_allowed": bool(write),
                                      "private_gate": bool(gate),
                                      "shared_prefeedback_values": self.pred_shared,
                                      "private_residual": None if residual is None else
                                          list(map(float, residual))})
        self.pred_shared = self.pred_combined = self.current_x = None

    def flush(self, t):
        return max(self.shared.flush(t), self.private.flush(t))


def from_fresh_births(arm: str, *, random_gates=None):
    import portable_birth as birth
    shared, private, receipts = [], [], []
    for bank in ("shared", "private"):
        for j in range(4):
            model, raw = birth.canonical_fresh_native()
            canonical = bc.v88().sparse_digest(model.fly.m.B)
            if canonical != birth.EXPECTED_B:
                raise AssertionError("R bank newborn B mismatch")
            if bank == "private":
                model = content_model.from_native(model)
            (shared if bank == "shared" else private).append(model)
            receipts.append({"bank": bank, "store": j, "raw_B_sha256": raw,
                             "canonical_B_sha256": canonical})
    if len({id(x.fly) for x in shared + private}) != 8:
        raise AssertionError("R banks share a newborn fly object")
    s = LedgerFourStore(shared, bank="shared")
    p = (SignedFourStore(private) if arm in ("R0_signed", "R3", "R3_randtarget")
         else LedgerFourStore(private, bank="private"))
    return RBank(s, p, arm, random_gates=random_gates), receipts
