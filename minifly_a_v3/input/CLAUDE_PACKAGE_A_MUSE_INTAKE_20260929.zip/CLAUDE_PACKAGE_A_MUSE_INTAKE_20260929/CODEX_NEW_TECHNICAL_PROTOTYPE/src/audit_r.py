"""Independent per-store and mechanism-event audit for two-bank R lives."""
from __future__ import annotations

import math
from collections import Counter

from audit_branch import BLOCKED, BRANCHES, audit_receipt
from fixture import DT, RECORD_SECONDS, make_world
NOVELTY_THRESHOLD = 0.20  # literal independent copy of the frozen candidate draft
SCALE_SHARED = 1.6010790608465912


def audit_r(receipt: dict) -> dict:
    arm, world = receipt.get("arm"), receipt.get("world")
    if arm not in ("R0", "R1", "R1_rand", "R0_signed", "R3", "R3_randtarget") or world != 190000:
        raise AssertionError("invalid R technical identity")
    # The common platform's aggregate counts refer to its four output
    # opportunities, not to the two-bank total. Audit shared as the literal
    # branch instrument, and private separately below.
    shared_copy = dict(receipt)
    shared_copy["write_ledger"] = [r for r in receipt["write_ledger"] if r["bank"] == "shared"]
    audit_receipt(shared_copy, banks=("shared",))
    fixture = make_world(world)
    ledger = [r for r in receipt["write_ledger"] if r["bank"] == "private"]
    if len(ledger) != 600 * 5 * 4:
        raise AssertionError("R private ledger incomplete")
    by_key = {(r["record"], r["branch"], r["store"]): r for r in ledger}
    if len(by_key) != len(ledger):
        raise AssertionError("R private write key duplicated")
    events = receipt.get("mechanism_events")
    if not isinstance(events, dict) or set(events) != set(BRANCHES):
        raise AssertionError("R mechanism-event branch roster incomplete")
    gate_counts = Counter()
    for branch in BRANCHES:
        if len(events[branch]) != 600:
            raise AssertionError("R pre-answer decision count wrong")
        for i, rec in enumerate(fixture["records"]):
            stage, domain, answer = rec["stage"], rec["domain"], rec["answer"]
            e = events[branch][i]
            allowed = BLOCKED[branch] != (stage, domain)
            novelty = e.get("pre_answer_novelty")
            if (e.get("world") != world or e.get("branch") != branch or e.get("record") != i or
                    e.get("stage") != stage or e.get("domain") != domain or
                    e.get("answer") != answer or e.get("causal_write_allowed") is not allowed or
                    not isinstance(novelty, (int, float)) or not 0 <= novelty <= 1):
                raise AssertionError(f"R mechanism event wrong at {branch}/{i}")
            if arm == "R1" and e["private_gate"] is not (novelty > NOVELTY_THRESHOLD):
                raise AssertionError("R1 novelty gate disagrees with recorded pre-answer novelty")
            active = 4 if domain == "fact" else 2
            when = i * RECORD_SECONDS + (86400 if stage == "new" else 0) + 12 * DT
            p = None
            if arm in ("R0_signed", "R3", "R3_randtarget"):
                logits = e["shared_prefeedback_values"][:active]
                exp = [math.exp(v / SCALE_SHARED - max(logits) / SCALE_SHARED) for v in logits]
                p = [v / sum(exp) for v in exp]
                target = answer - 48
                ordinary = [(1.0 if j == target else 0.0) - p[j] for j in range(active)]
                if arm == "R3" and any(abs(a - b) > 1e-12 for a, b in zip(e["private_residual"], ordinary)):
                    raise AssertionError("R3 signed residual wrong")
                if arm == "R3_randtarget" and any(abs(a - b) > 1e-12 for a, b in zip(
                        sorted(e["private_residual"]), sorted(ordinary))):
                    raise AssertionError("R3 random target changed the residual dose")
            for j in range(4):
                r = by_key.get((i, branch, j))
                if r is None or any((r.get("world") != world, r.get("stage") != stage,
                                     r.get("domain") != domain, r.get("answer") != answer,
                                     r.get("bank") != "private", r.get("store") != j,
                                     not math.isclose(float(r.get("teacher_at", -1)), when, abs_tol=1e-8))):
                    raise AssertionError(f"R private exposure wrong at {branch}/{i}/{j}")
                expected = allowed and j < active and (arm not in ("R1", "R1_rand") or e["private_gate"])
                if arm in ("R3", "R3_randtarget"):
                    expected = expected and e["private_residual"][j] != 0 if j < active else False
                if r["write"] is not bool(expected):
                    raise AssertionError(f"R private write wrong at {branch}/{i}/{j}")
                if p is not None:
                    expected_punishment = (1.0 - float(j == answer - 48) if arm == "R0_signed"
                                           else 0.5 - e["private_residual"][j] / 2.0) if j < active else 0.5
                    if abs(r.get("punishment", -99) - expected_punishment) > 1e-12:
                        raise AssertionError("R signed teaching dose wrong")
                gate_counts[(branch, stage, domain, answer)] += int(r["write"])
    births = receipt.get("birth")
    if not isinstance(births, list) or len(births) != 8 or len({(b["bank"], b["store"]) for b in births}) != 8:
        raise AssertionError("eight R newborn records missing")
    if any(b["canonical_B_sha256"] != "32a3726cb25a8255c1aef5696ff40aa303138c5d061a598004d2087d4da5f964" for b in births):
        raise AssertionError("R birth B differs from canonical")
    return {"pass": True, "arm": arm, "world": world,
            "private_rows": len(ledger), "shared_rows": len(shared_copy["write_ledger"]),
            "private_writes": sum(gate_counts.values())}
