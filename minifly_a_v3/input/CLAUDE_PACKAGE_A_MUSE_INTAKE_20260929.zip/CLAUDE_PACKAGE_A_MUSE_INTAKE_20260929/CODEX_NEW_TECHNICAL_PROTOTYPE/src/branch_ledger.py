"""Observed write-decision ledger for a four-store technical life.

The independent auditor is in audit_branch.py and does not import this class.
"""
from __future__ import annotations

import paths  # noqa: F401
from common_platform import CHANNELS, FourStore, clone_model


class LedgerFourStore(FourStore):
    def __init__(self, stores, *, bank: str = "native", register_children: bool = True):
        super().__init__(stores)
        self.bank = bank
        self.write_ledger = []
        self.branch_children = []
        self.register_children = register_children

    def clone(self):
        out = LedgerFourStore([clone_model(m) for m in self.stores], bank=self.bank,
                              register_children=False)
        out.context = self.context
        out.mechanism_events = list(self.mechanism_events)
        if self.register_children:
            self.branch_children.append(out)
        return out

    def teach(self, answer: int, t: float, domain: str, *, write: bool):
        if self.context is None:
            raise AssertionError("record context missing")
        world, branch, index, stage, declared = self.context
        if declared != domain:
            raise AssertionError("record domain changed")
        if answer not in CHANNELS:
            raise AssertionError("unrecognized answer byte")
        active = 4 if domain == "fact" else 2
        rows = [{"world": world, "branch": branch, "record": index,
                 "stage": stage, "domain": domain, "bank": self.bank,
                 "store": j, "write": bool(write and j < active),
                 "answer": answer, "teacher_at": float(t)} for j in range(4)]
        super().teach(answer, t, domain, write=write)
        self.write_ledger.extend(rows)


def ledgers_from_actor(actor, branches):
    if len(actor.branch_children) != len(branches):
        raise AssertionError("branch clone registry incomplete")
    result = []
    for branch, child in zip(branches, actor.branch_children, strict=True):
        if len(child.write_ledger) != 600 * 4:
            raise AssertionError(f"per-store ledger incomplete: {branch}")
        if any(row["branch"] != branch for row in child.write_ledger):
            raise AssertionError("branch clone registry misaligned")
        result.extend(child.write_ledger)
    return result
