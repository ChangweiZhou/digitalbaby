"""Fixed-support PN→KC weight rules for Package A's technical qualification.

No outcome byte, answer label, teacher bit or scored correctness enters the P
update. Native Full151 teaching remains the shared platform. P0 carries the
same sensory traces and norm bookkeeping without changing B.
"""
from __future__ import annotations

import copy
import hashlib
import math
import numpy as np

import paths  # noqa: F401
from brain_byte import F151ByteBrain, bc
from branch_ledger import LedgerFourStore
from common_platform import clone_model

ARMS = ("P0", "P1", "P2", "P4")
ETA = 0.001
TAU_TIMING = 300.0
MIN_WEIGHT = 1e-9


def csr_structure_digest(b):
    h = hashlib.sha256()
    h.update(np.ascontiguousarray(b.indptr).tobytes())
    h.update(np.ascontiguousarray(b.indices).tobytes())
    return h.hexdigest()


def csr_data_digest(b):
    return hashlib.sha256(np.ascontiguousarray(b.data).tobytes()).hexdigest()


class PBrain(F151ByteBrain):
    @classmethod
    def from_canonical_newborn(cls, base: F151ByteBrain, arm: str):
        if type(base) is not F151ByteBrain or arm not in ARMS or base.bytes_seen:
            raise ValueError("P conversion requires its own canonical fresh store")
        base.__class__ = cls
        base.p_arm = arm
        base.fly.m.B = base.fly.m.B.copy()
        b = base.fly.m.B
        base.p_rows = np.repeat(np.arange(b.shape[0], dtype=np.int32), np.diff(b.indptr))
        base.p_cols = b.indices.copy()
        base.p_structure = csr_structure_digest(b)
        base.p_birth_data = csr_data_digest(b)
        base.p_birth_sum = np.bincount(base.p_cols, weights=b.data,
                                       minlength=b.shape[1]).astype(np.float64)
        base.p_last_pre_p = None
        base.p_last_pre_x = None
        base.p_prev_p = np.zeros(b.shape[0], dtype=np.float64)
        base.p_prev_x = np.zeros(b.shape[1], dtype=np.float64)
        base.p_prev_t = None
        base.p_event = None
        base.p_events = 0
        return base

    def clone(self):
        out = copy.copy(self)
        out.fly = self.fly.clone()
        out.fly.m.B = self.fly.m.B.copy()
        out.fe = self.fe.clone()
        out.w = self.w.copy()
        out.bias = self.bias.copy()
        out.pending_x = None if self.pending_x is None else self.pending_x.copy()
        out.p_last_pre_p = None if self.p_last_pre_p is None else self.p_last_pre_p.copy()
        out.p_last_pre_x = None if self.p_last_pre_x is None else self.p_last_pre_x.copy()
        out.p_prev_p = self.p_prev_p.copy()
        out.p_prev_x = self.p_prev_x.copy()
        out.p_event = None if self.p_event is None else dict(self.p_event)
        if out.fly.m.B is self.fly.m.B or out.state_digest() != self.state_digest():
            raise AssertionError("P clone alias or digest mismatch")
        return out

    def byte(self, b: int, t: float, learn: bool = True, **kwargs):
        # Capture pre-arrival sensory state. For the answer byte, this is the
        # complete cue state and remains independent of the answer's identity.
        trial_fe = self.fe.clone()
        trial_fe.advance(float(t))
        pre_p = np.asarray(trial_fe.read(), dtype=np.float64)
        result = super().byte(b, t, learn=learn, **kwargs)
        self.p_last_pre_p = pre_p[self.fly.m.pn_type_index].copy()
        self.p_last_pre_x = self.pending_x.copy()
        return result

    def _sensory_update(self, p: np.ndarray, x: np.ndarray, t: float):
        b = self.fly.m.B
        if csr_structure_digest(b) != self.p_structure:
            raise AssertionError("PN→KC partner structure changed")
        if not (np.isfinite(p).all() and np.isfinite(x).all()):
            raise FloatingPointError("nonfinite pre-outcome sensory state")
        pre = b.data.copy()
        co = p[self.p_rows] * x[self.p_cols]
        if self.p_arm == "P1":
            delta = ETA * co
        elif self.p_arm == "P2":
            # Oja's stabilising term is explicitly -x_k^2 * w_ik.
            delta = ETA * (co - x[self.p_cols] ** 2 * pre)
        elif self.p_arm == "P4":
            decay = 0.0 if self.p_prev_t is None else math.exp(
                -max(0.0, t - self.p_prev_t) / TAU_TIMING)
            delta = ETA * decay * (self.p_prev_p[self.p_rows] * x[self.p_cols]
                                   - p[self.p_rows] * self.p_prev_x[self.p_cols])
        else:
            delta = np.zeros_like(pre)
        if self.p_arm != "P0":
            data = np.maximum(MIN_WEIGHT, pre + delta)
            current_sum = np.bincount(self.p_cols, weights=data, minlength=b.shape[1])
            scale = np.divide(self.p_birth_sum, current_sum,
                              out=np.ones_like(current_sum), where=current_sum > 0)
            data *= scale[self.p_cols]
            if not np.isfinite(data).all() or (data <= 0).any():
                raise FloatingPointError("P weight left finite positive range")
            b.data[:] = data
        self.p_prev_p[:] = p
        self.p_prev_x[:] = x
        self.p_prev_t = float(t)
        self.p_events += 1
        self.p_event = {"arm": self.p_arm, "event": self.p_events, "t": float(t),
                        "coactivity_l1": float(np.abs(co).sum()),
                        "local_delta_l1": float(np.abs(delta).sum()),
                        "actual_weight_delta_l1": float(np.abs(b.data - pre).sum()),
                        "structure_sha256": self.p_structure,
                        "weights_sha256": csr_data_digest(b)}

    def teach(self, r: int, t: float, *, write: bool = True):
        if self.p_last_pre_p is None or self.p_last_pre_x is None:
            raise AssertionError("pre-outcome sensory state missing")
        p, x = self.p_last_pre_p.copy(), self.p_last_pre_x.copy()
        result = super().teach(r, t, write=write)
        self._sensory_update(p, x, float(t))
        self.p_last_pre_p = self.p_last_pre_x = None
        return result

    def state_digest(self):
        h = hashlib.sha256()
        h.update(super().state_digest().encode())
        h.update(csr_structure_digest(self.fly.m.B).encode())
        h.update(csr_data_digest(self.fly.m.B).encode())
        for a in (self.p_prev_p, self.p_prev_x, self.p_last_pre_p, self.p_last_pre_x):
            h.update(b"NONE" if a is None else np.ascontiguousarray(a).tobytes())
        h.update(str((self.p_arm, self.p_prev_t, self.p_events)).encode())
        return h.hexdigest()


class PFourStore(LedgerFourStore):
    def __init__(self, stores, *, register_children=True):
        super().__init__(stores, bank="native", register_children=register_children)

    def clone(self):
        out = PFourStore([clone_model(m) for m in self.stores], register_children=False)
        out.context = self.context
        out.mechanism_events = list(self.mechanism_events)
        if self.register_children:
            self.branch_children.append(out)
        return out

    def teach(self, answer: int, t: float, domain: str, *, write: bool):
        super().teach(answer, t, domain, write=write)
        for j, store in enumerate(self.stores):
            self.mechanism_events.append({"context": self.context, "store": j,
                                          "write": bool(write and (domain == "fact" or j < 2)),
                                          **store.p_event})
