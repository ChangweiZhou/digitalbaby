# V201 official results

**ADVANCE_TO_CONFIRMATION**. All 16 worlds completed. MiniFly chose all 10,240 live actions and received only their sampled consequences. The shadows consumed the same history.

| Arm | Final trained | Final held |
|---|---:|---:|
| ALIGNED | 100.00% | 100.00% |
| SHUFFLED | 57.81% | 67.19% |
| NO-WRITE | 50.00% | 50.00% |

- ALIGNED minus SHUFFLED +32.81%, paired 95% interval [+18.45%, +47.18%].
- ALIGNED minus NO-WRITE +50.00%, paired 95% interval [+50.00%, +50.00%].

The assay grades changed renderings of known cues. It uses supplied exploration and one in-flight action.
